

from django.contrib import admin

from .models import Choice, Question,CostCenter,SourceOfFund,PPMP,Category,Item,ItemDescription,Prices,OrderDetails



admin.site.register(CostCenter)
admin.site.register(SourceOfFund)
admin.site.register(PPMP)
admin.site.register(Category)
admin.site.register(Item)
admin.site.register(ItemDescription)
admin.site.register(Prices)
admin.site.register(OrderDetails)