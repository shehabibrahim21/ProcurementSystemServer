from django.urls import path
from django.conf.urls import url, include
from . import views
from django.views.generic import TemplateView
app_name = 'PPMP'
urlpatterns = [
    path('', views.index, name='index'),
    path(r'^index/index-(?P<parameter>[\w-]+).html', views.ppmp, name='ppmp'),
    path('<int:pk>/', views.DetailView.as_view(), name='detail'),
    path('<int:pk>/results/', views.ResultsView.as_view(), name='results'),
    path('<int:question_id>/vote/', views.vote, name='vote'),


]