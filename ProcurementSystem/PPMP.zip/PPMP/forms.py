import datetime

from django import forms
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext_lazy as _
import GetYear as gy
from django.utils.safestring import mark_safe
category_choices = [('category','Category'),('all','All')]

class CategoryForm(forms.Form):

    category= forms.CharField(label = False,required=False, widget=forms.Select(choices=category_choices))



class SearchForm(forms.Form):
    name = forms.CharField(label = 'Search Category',required=False,
        widget=forms.TextInput(attrs={'id': 'autocomplete_name','class':'autocomplete_name'})
    )

class SearchItemForm(forms.Form):
    name = forms.CharField(label = False,required=False,
        widget=forms.TextInput(attrs={'id': 'autocomplete_gen','class':'autocomplete_gen','size': 50})
    )



class Specifics1(forms.Form):
    specifics1 = forms.CharField(label = False,required=False,
        widget=forms.TextInput(attrs={'id': 'autocomplete_item1','class':'autocomplete_item1','size': 50})
    )
class Specifics2(forms.Form):
    specifics2 = forms.CharField(label = False,required=False,
        widget=forms.TextInput(attrs={'id': 'autocomplete_item2','class':'autocomplete_item2','size': 50})
    )
class Specifics3(forms.Form):
    specifics3 = forms.CharField(label = False,required=False,
        widget=forms.TextInput(attrs={'id': 'autocomplete_item3','class':'autocomplete_item3','size': 50})
    )
class Specifics4(forms.Form):
    specifics4 = forms.CharField(label = False,required=False,
        widget=forms.TextInput(attrs={'id': 'autocomplete_item4','class':'autocomplete_item4','size': 50})
    )
class Specifics5(forms.Form):
    specifics5 = forms.CharField(label = False,required=False,
        widget=forms.TextInput(attrs={'id': 'autocomplete_item5','class':'autocomplete_item5','size': 50})
    )


class Quarter1(forms.Form):
    quarter1 = forms.CharField(label = False,required=False,
        widget=forms.TextInput(attrs={'id': 'number11','class':'number11','size': 10})
    )

class Quarter2(forms.Form):
    quarter2 = forms.CharField(label = False,required=False,
        widget=forms.TextInput(attrs={'id': 'number22','class':'number22','size': 10})
    )
class Quarter3(forms.Form):
    quarter3 = forms.CharField(label = False,required=False,
        widget=forms.TextInput(attrs={'id': 'number33','class':'number33','size': 10})
    )
class Quarter4(forms.Form):
    quarter4 = forms.CharField(label = False,required=False,
        widget=forms.TextInput(attrs={'id': 'number44','class':'number44','size': 10})
    )



class CostCenterCode(forms.Form):

    cc_code = forms.CharField(label = False,required=False,
        widget=forms.TextInput()
    )

class CostCenterName(forms.Form):


    cc_name= forms.CharField(label = False,required=False,
        widget=forms.TextInput()
    )

year_choices = gy.get_year()
# year_choices = [('category','Category'),('all','All')]
class YearForm(forms.Form):

    year= forms.CharField(label='Year',required=False, widget=forms.Select(choices=year_choices, attrs={'name': 'yc'}))

