from django.http import HttpResponseRedirect
from django.shortcuts import get_object_or_404, render
from django.urls import reverse
from django.views import generic
from django.utils import timezone
from .models import Choice, Question
from PPMP.forms import CostCenterCode
from PPMP.forms import CostCenterName
from PPMP.forms import YearForm
from PPMP.forms import CategoryForm
from PPMP.forms import SearchItemForm
from PPMP.forms import Specifics1
from PPMP.forms import Specifics2
from PPMP.forms import Specifics3
from PPMP.forms import Specifics4
from PPMP.forms import Specifics5
from PPMP.forms import Quarter1
from PPMP.forms import Quarter2
from PPMP.forms import Quarter3
from PPMP.forms import Quarter4
import InputCleaning as  ic
import GetItemsList as gil
import RetrieveSpecifications as  rs
import GetDetails as gd
import GetPPMP as gp
import GetCostCenters as gc
import GetCategory as gcat
import CheckIfExists as cie
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from HR.forms import SearchForm
import numpy as np
import GetCategoryCode as gcc

lst_num = list(np.arange(0,99999))
lst_num = [str(i) for i in lst_num]

class GlobalVariables():
    ppmp = ''
    ppmp_id = ''
    cc_code = ''
    cc_name = ''
    fs_name = ''
    yr = ''
    type = ''
    remarks = ''
    lst_ppmp = ''
    lst_ppmp_id = ''
    cat_code = ''


@login_required
def index(request):
    user = request.user
    lst_cc = gc.get_cost_centers(user)
    context = {
    'lst_cc':lst_cc,
    'modal_type': 'Zero',
    }
    return render(request, 'PPMP/index.html', context)


#
def ppmp(request,parameter):
    print(GlobalVariables.ppmp, 'start')
    categories = gcat.get_categories()
    dropdownform = YearForm(request.POST)
    user = request.user
    lst_cc = gc.get_cost_centers(user)
    if parameter == '999990':
        with_content = False

        context = {
            'lst_cc': lst_cc,
            'modal_type': 'One',
            'with_content': with_content
        }
    elif parameter == '999991':  ### Update Year
        with_content = True

        parameter = GlobalVariables.ppmp_id
        GlobalVariables.yr = request.POST.get('year')
        lst_ppmp = gp.get_ppmp(parameter[0], request.POST.get('year'))
        GlobalVariables.lst_ppmp = lst_ppmp
        GlobalVariables.cc_code = parameter[0]
        GlobalVariables.cc_name = parameter[1]

        # print(parameter)
        context = {
            'lst_cc': lst_cc,
            'modal_type': 'One',
            'with_content': with_content,
            'course_code': parameter[0],
            'course_name': parameter[1],
            'lst_ppmp': lst_ppmp,
            'dropdownform': dropdownform
        }

    elif parameter == '999993': ### Create PPMP

        categoryform = CategoryForm(request.POST)
        searchform = SearchForm(request.POST)
        GlobalVariables.fs_name = GlobalVariables.lst_ppmp_id[2]
        GlobalVariables.yr = GlobalVariables.lst_ppmp_id[3]
        GlobalVariables.type = GlobalVariables.lst_ppmp_id[4]
        GlobalVariables.remarks =GlobalVariables.lst_ppmp_id[4]
        if searchform.is_valid():
            # index = int(GlobalVariables.ppmp)
            # pass

            raw_data = searchform.cleaned_data['name']
            with_categories = True
            cat_code = gcc.get_cat_code(raw_data)
            GlobalVariables.cat_code = cat_code
            print(raw_data)
            context = {
                'cat_code': cat_code,
                'cat_name': raw_data,
                'with_categories': with_categories,
                'lst_cc': lst_cc,
                'modal_type': 'Three',
                'with_content': False,
                'cc_code': GlobalVariables.cc_code,
                'cc_name': GlobalVariables.cc_name,
                'fs_name': GlobalVariables.fs_name,
                'yr': GlobalVariables.yr,
                'type': GlobalVariables.type,
                'remarks': GlobalVariables.remarks,
                'categoryform': categoryform,
                'searchform': searchform,
                "categories": categories,

            }


        else:
            with_categories = False

            context = {
                'with_categories': with_categories,
                'lst_cc': lst_cc,
                'modal_type': 'Three',
                'with_content': False,
                'cc_code': GlobalVariables.cc_code,
                'cc_name' : GlobalVariables.cc_name,
                'fs_name' : GlobalVariables.fs_name,
                'yr' : GlobalVariables.yr,
                'type' : GlobalVariables.type,
                'remarks' : GlobalVariables.remarks,
                'categoryform': categoryform,
                'searchform':searchform,
                "categories": categories,

        }
    elif parameter == '999994': ### Change Category

        categoryform = CategoryForm(request.POST)
        category = request.POST.get('category')
        context = {
            'categoryform': categoryform,
            'category':category
        }


    elif  parameter == '999995': #### Back
        with_content = True
        show_buttons = False
        parameter  = GlobalVariables.ppmp_id
        lst_ppmp = GlobalVariables.lst_ppmp
        context = {
            'lst_cc': lst_cc,
            'modal_type': 'One',
            'with_content': with_content,
            'course_code': parameter[0],
            'course_name': parameter[1],
            'lst_ppmp': lst_ppmp,
            'dropdownform': dropdownform,
            'show_buttons': show_buttons
        }

    elif  parameter == '999996': #### Back
        with_content = True
        show_buttons = False
        parameter  = GlobalVariables.ppmp_id
        lst_ppmp = GlobalVariables.lst_ppmp
        context = {
            'lst_cc': lst_cc,
            'modal_type': 'One',
            'with_content': with_content,
            'course_code': parameter[0],
            'course_name': parameter[1],
            'lst_ppmp': lst_ppmp,
            'dropdownform': dropdownform,
            'show_buttons': show_buttons
        }

    elif  parameter == '999997': #### Add ITEMS
        searchitemform = SearchItemForm(request.POST)
        specifics1 = Specifics1(request.POST)
        specifics2 = Specifics2(request.POST)
        specifics3 = Specifics3(request.POST)
        specifics4 = Specifics4(request.POST)
        specifics5 = Specifics5(request.POST)
        quarter1 = Quarter1(request.POST)
        quarter2 = Quarter2(request.POST)
        quarter3 = Quarter3(request.POST)
        quarter4 = Quarter4(request.POST)
        cat_code = GlobalVariables.cat_code
        generics = gil.get_gen(cat_code)
        specifics = gil.get_spec(cat_code)
        if searchitemform.is_valid():
            gen = searchitemform.cleaned_data['name'].strip()
            try:
                s1 = request.POST.get('specifics1').strip()
            except:
                s1 = 'None'
            try:
                s2 = request.POST.get('specifics2').strip()
            except:
                s2 = 'None'
            try:
                s3 = request.POST.get('specifics3').strip()
            except:
                s3 = 'None'
            try:
                s4 = request.POST.get('specifics4').strip()
            except:
                s4 = 'None'
            try:
                s5 = request.POST.get('specifics5').strip()
            except:
                s5 = 'None'

            if s1 =='':
                s1 = 'None'
            if s2 == '':
                s2 = 'None'
            if s3 == '':
                s3 = 'None'
            if s4 == '':
                s4 = 'None'
            if s5 == '':
                s5 = 'None'

            lst = [gen,s1,s2,s3,s4,s5]
            # print(lst)
            if cie.check(lst,cat_code):
                # print(lst,cat_code)
                price,unit = cie.get_price_unit(lst,cat_code)
                lst1 = [elem for elem in lst if elem != 'None']
                given_items = ' '.join(lst1).upper()
                context = {
                    'quarter1':quarter1,
                    'quarter2': quarter2,
                    'quarter3': quarter3,
                    'quarter4': quarter4,
                    'initial':0,
                    'price':price,
                    'unit':unit,
                    'given_items': given_items,
                    'found': True,
                    'specifics1': specifics1,
                    'specifics2': specifics2,
                    'specifics3': specifics3,
                    'specifics4': specifics4,
                    'specifics5': specifics5,
                    'generics': generics,
                    'specifics': specifics,
                    'searchitemform': searchitemform,
                    'lst_cc': lst_cc,
                    'modal_type': 'Four',
                    'dropdownform': dropdownform,
                    'cat_code': cat_code,

                }

            else:
                print('Not Exists')


                context = {
                    'specifics1': specifics1,
                    'specifics2': specifics2,
                    'specifics3': specifics3,
                    'specifics4': specifics4,
                    'specifics5': specifics5,
                    'generics': generics,
                    'specifics': specifics,
                    'searchitemform':searchitemform,
                    'lst_cc': lst_cc,
                    'modal_type': 'Four',
                    'dropdownform': dropdownform,
                    'cat_code': cat_code,

                }
    elif parameter == '999998':  #### Add ITEMS
        pass
    elif parameter in lst_num: #### Select PPMP ID

        with_content = True
        show_buttons = True
        GlobalVariables.ppmp = parameter
        lst_ppmp_id = []
        for i in  GlobalVariables.lst_ppmp :
            if i[0] == int(parameter):
                lst_ppmp_id = i
                break

        GlobalVariables.lst_ppmp_id = lst_ppmp_id

        context = {
            'lst_cc': lst_cc,
            'modal_type': 'One',
            'with_content': with_content,
            'lst_ppmp' : GlobalVariables.lst_ppmp,
            'lst_ppmp_id': lst_ppmp_id,
            'dropdownform': dropdownform,
            'show_buttons': show_buttons,
            'course_code': GlobalVariables.cc_code,
            'course_name': GlobalVariables.cc_name,
        }



    else: #### Select Cost Center
        with_content = True
        show_buttons = False
        parameter = parameter.replace('[','')
        parameter = parameter.replace(']', '')
        parameter = parameter.split(',')
        parameter = [word.strip()[1:-1] for word in parameter]
        GlobalVariables.ppmp_id = parameter
        print(GlobalVariables.ppmp)
        lst_ppmp = gp.get_ppmp(parameter[0])
        GlobalVariables.lst_ppmp = lst_ppmp
        # print(lst_ppmp)
        GlobalVariables.cc_code = parameter[0]
        GlobalVariables.cc_name = parameter[1]
        GlobalVariables.fs_name = lst_ppmp[0][2]
        GlobalVariables.yr = lst_ppmp[0][3]
        GlobalVariables.type = lst_ppmp[0][4]
        GlobalVariables.remarks = lst_ppmp[0][4]
        context = {
            'lst_cc': lst_cc,
            'modal_type': 'One',
            'with_content': with_content,
            'course_code': parameter[0],
            'course_name': parameter[1],
            'lst_ppmp': lst_ppmp,
            'dropdownform': dropdownform,
            'show_buttons': show_buttons
        }


    return render(request, 'PPMP/index.html', context)




class IndexView(generic.ListView):
    template_name = 'PPMP/index.html'
    context_object_name = 'latest_question_list'

    def get_queryset(self):
        """Return the last five published questions."""
        return Question.objects.order_by('-pub_date')[:5]


class DetailView(generic.DetailView):
    model = Question
    template_name = 'PPMP/detail.html'


class ResultsView(generic.DetailView):
    model = Question
    template_name = 'PPMP/results.html'


def vote(request, question_id):
    question = get_object_or_404(Question, pk=question_id)
    try:
        selected_choice = question.choice_set.get(pk=request.POST['choice'])
    except (KeyError, Choice.DoesNotExist):
        # Redisplay the question voting form.
        return render(request, 'PPMP/detail.html', {
            'question': question,
            'error_message': "You didn't select a choice.",
        })
    else:
        selected_choice.votes += 1
        selected_choice.save()
        # Always return an HttpResponseRedirect after successfully dealing
        # with POST data. This prevents data from being posted twice if a
        # user hits the Back button.
        return HttpResponseRedirect(reverse('HR:results', args=(question.id,)))



def results(request, question_id):
    question = get_object_or_404(Question, pk=question_id)
    return render(request, 'polls/results.html', {'question': question})


def get_queryset(self):
    """
    Return the last five published questions (not including those set to be
    published in the future).
    """
    return Question.objects.filter(
        pub_date__lte=timezone.now()
    ).order_by('-pub_date')[:5]